Config = {}
Config.Locale = GetConvar('esx:locale', 'en')

Config.DrawDistance = 10.0

Config.Markers = {
	EntryPoint = {
		Type = 21,
		Size = {
			x = 1.0,
			y = 1.0,
			z = 0.5,
		},
		Color = {
			r = 50,
			g = 200,
			b = 50,
		},
	},
	GetOutPoint = {
		Type = 21,
		Size = {
			x = 1.0,
			y = 1.0,
			z = 0.5,
		},
		Color = {
			r = 200,
			g = 51,
			b = 51,
		},
	},
}

Config.Garages = {
	VespucciBoulevard = {
		EntryPoint = {
			x = -285.2,
			y = -886.5,
			z = 31.0,
		},
		SpawnPoint = {
			x = -309.3,
			y = -897.0,
			z = 31.0,
			heading = 351.8,
		},
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	SanAndreasAvenue = {
		EntryPoint = {
			x = 216.4,
			y = -786.6,
			z = 30.8,
		},
		SpawnPoint = {
			x = 218.9,
			y = -779.7,
			z = 30.8,
			heading = 338.8,
		},
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	SandyShoresGarage = {
		EntryPoint = {
			x = 1842.0177,
			y = 3668.0891,
			z = 32.6800,
		},
		SpawnPoint = {
			x = 1842.0177,
			y = 3668.0891,
			z = 32.6800,
			heading = 306.4543,
		},
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "SandyShores",
	},
	VinewoodDowntown = {
		EntryPoint = { x = 604.8, y = 90.7, z = 92.9 },
		SpawnPoint = { x = 597.4, y = 91.5, z = 92.9, heading = 100.5 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	DelPerroBeach = {
		EntryPoint = { x = -1510.8, y = -568.2, z = 33.5 },
		SpawnPoint = { x = -1502.1, y = -562.9, z = 33.5, heading = 30.2 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	PillboxHill = {
		EntryPoint = { x = -41.3, y = -1066.8, z = 26.6 },
		SpawnPoint = { x = -51.3, y = -1071.0, z = 26.6, heading = 70.0 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	LSAirport = {
		EntryPoint = { x = -1151.7, y = -2724.7, z = 19.8 },
		SpawnPoint = { x = -1141.7, y = -2710.2, z = 19.8, heading = 148.5 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	PaletoBayMain = {
		EntryPoint = { x = 111.9, y = 6607.7, z = 31.8 },
		SpawnPoint = { x = 113.8, y = 6614.8, z = 31.8, heading = 265.4 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "PaletoBay",
	},
	GrapeseedMain = {
		EntryPoint = { x = 1686.2, y = 4781.0, z = 42.0 },
		SpawnPoint = { x = 1679.5, y = 4785.4, z = 42.0, heading = 100.2 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "SandyShores",
	},
	LaPuerta = {
		EntryPoint = { x = -871.9, y = -1113.7, z = 7.0 },
		SpawnPoint = { x = -864.8, y = -1124.6, z = 7.0, heading = 32.5 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	MirrorPark = {
		EntryPoint = { x = 1041.6, y = -773.9, z = 57.9 },
		SpawnPoint = { x = 1032.5, y = -765.2, z = 57.9, heading = 315.0 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
	PacificBluffs = {
		EntryPoint = { x = -2150.1, y = -368.4, z = 13.2 },
		SpawnPoint = { x = -2138.5, y = -374.3, z = 13.2, heading = 270.0 },
		Sprite = 357,
		Scale = 0.8,
		Colour = 3,
		ImpoundedName = "LosSantos",
	},
}

Config.Impounds = {
	LosSantos = {
		GetOutPoint = {
			x = 400.7,
			y = -1630.5,
			z = 29.3,
		},
		SpawnPoint = {
			x = 401.9,
			y = -1647.4,
			z = 29.2,
			heading = 323.3,
		},
		Sprite = 524,
		Scale = 0.8,
		Colour = 1,
		Cost = 3000,
	},
	PaletoBay = {
		GetOutPoint = {
			x = -211.4,
			y = 6206.5,
			z = 31.4,
		},
		SpawnPoint = {
			x = -204.6,
			y = 6221.6,
			z = 30.5,
			heading = 227.2,
		},
		Sprite = 524,
		Scale = 0.8,
		Colour = 1,
		Cost = 3000,
	},
	SandyShores = {
		GetOutPoint = {
			x = 1728.2,
			y = 3709.3,
			z = 33.2,
		},
		SpawnPoint = {
			x = 1722.7,
			y = 3713.6,
			z = 33.2,
			heading = 19.9,
		},
		Sprite = 524,
		Scale = 0.8,
		Colour = 1,
		Cost = 3000,
	},
}

exports("getGarages", function()
	return Config.Garages
end)
exports("getImpounds", function()
	return Config.Impounds
end)

