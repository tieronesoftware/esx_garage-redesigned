RegisterServerEvent('esx_garage:updateOwnedVehicle')
AddEventHandler('esx_garage:updateOwnedVehicle', function(stored, parking, Impound, data, spawn)
	local source = source
	local xPlayer  = ESX.Player(source)
		MySQL.update('UPDATE owned_vehicles SET `stored` = @stored, `parking` = @parking, `pound` = @Impound, `vehicle` = @vehicle WHERE `plate` = @plate AND `owner` = @identifier',
		{
			['@identifier'] = xPlayer.getIdentifier(),
			['@vehicle'] 	= json.encode(data.vehicleProps),
			['@plate'] 		= data.vehicleProps.plate,
			['@stored']     = stored,
			['@parking']    = parking,
			['@Impound']    	= Impound
		})

		if stored then
			xPlayer.showNotification(TranslateCap('veh_stored'))
		else 
			ESX.OneSync.SpawnVehicle(data.vehicleProps.model, spawn, data.spawnPoint.heading,data.vehicleProps, function(vehicle)
				local vehicle = NetworkGetEntityFromNetworkId(vehicle)
				Wait(300)
				TaskWarpPedIntoVehicle(GetPlayerPed(source), vehicle, -1)
			end)
		end
end)

RegisterServerEvent('esx_garage:setImpound')
AddEventHandler('esx_garage:setImpound', function(Impound, vehicleProps)
	local source = source
	local xPlayer  = ESX.Player(source)

		MySQL.update('UPDATE owned_vehicles SET `stored` = @stored, `pound` = @Impound, `vehicle` = @vehicle WHERE `plate` = @plate AND `owner` = @identifier',
		{
			['@identifier'] = xPlayer.getIdentifier(),
			['@vehicle'] 	= json.encode(vehicleProps),
			['@plate'] 		= vehicleProps.plate,
			['@stored']     = 2,
			['@Impound']    	= Impound
		})

		xPlayer.showNotification(TranslateCap('veh_impounded'))
end)


-- SV: Tanggalin ang @parking filter para makita lahat ng sasakyan kahit saang garage
ESX.RegisterServerCallback('esx_garage:getVehiclesInParking', function(source, cb, parking)
    local xPlayer = ESX.GetPlayerFromId(source)

    -- Inalis ang `AND parking = @parking` sa query
    MySQL.query('SELECT * FROM `owned_vehicles` WHERE `owner` = @identifier AND `stored` = 1',
    {
        ['@identifier'] = xPlayer.getIdentifier()
    }, function(result)
        local vehicles = {}
        for i = 1, #result, 1 do
            table.insert(vehicles, {
                vehicle = json.decode(result[i].vehicle),
                plate   = result[i].plate
            })
        end

        cb(vehicles)
    end)
end)

ESX.RegisterServerCallback('esx_garage:checkVehicleOwner', function(source, cb, plate)
    local xPlayer = ESX.Player(source)

	MySQL.query('SELECT COUNT(*) as count FROM `owned_vehicles` WHERE `owner` = @identifier AND `plate` = @plate',
	{
		['@identifier'] 	= xPlayer.getIdentifier(),
		['@plate']     		= plate
	}, function(result)

		if tonumber(result[1].count) > 0 then
			return cb(true)
		else
			return cb(false)
		end
	end)
end)

-- Pounds part
ESX.RegisterServerCallback('esx_garage:getVehiclesImpounded', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)

	-- Kinukuha lahat ng sasakyang wala sa garage (stored = 0)
	MySQL.query('SELECT * FROM `owned_vehicles` WHERE `owner` = @identifier AND `stored` = 0',
	{
		['@identifier'] = xPlayer.getIdentifier(),
	}, function(result)
		local vehicles = {}
		
		for i = 1, #result, 1 do
			table.insert(vehicles, {
				vehicle = json.decode(result[i].vehicle),
				plate   = result[i].plate
			})
		end

		cb(vehicles)
	end)
end)

-- SV: Lahat ng impounded vehicles (stored = 2) ay makikita kahit saang pound
ESX.RegisterServerCallback('esx_garage:getVehiclesInPound', function(source, cb, Impound)
	local xPlayer = ESX.GetPlayerFromId(source)

	-- Inalis ang `AND pound = @Impound`
	MySQL.query('SELECT * FROM `owned_vehicles` WHERE `owner` = @identifier AND `stored` = 2',
	{
		['@identifier'] = xPlayer.getIdentifier()
	}, function(result)
		local vehicles = {}

		for i = 1, #result, 1 do
			table.insert(vehicles, {
				vehicle = json.decode(result[i].vehicle),
				plate   = result[i].plate
			})
		end

		cb(vehicles)
	end)
end)

ESX.RegisterServerCallback('esx_garage:checkMoney', function(source, cb, amount)
	local xPlayer = ESX.Player(source)

	cb(xPlayer.getMoney() >= amount)
end)

RegisterServerEvent("esx_garage:payPound")
AddEventHandler("esx_garage:payPound", function(amount)
		local source = source
    local xPlayer = ESX.Player(source)

    if xPlayer.getMoney() >= amount then
        xPlayer.removeMoney(amount, "Impound Fee")
				xPlayer.showNotification(TranslateCap('pay_Impound_bill', amount))
    else
		xPlayer.showNotification(TranslateCap('missing_money'))
    end
end)

